package org.richardliao.mybatis.model;

public class SysRolePrivilege {
    private Long roleId;

    private Long privilegeId;

    public Long getRoleId() {
	return this.roleId;
    }
    public void setRoleId(Long roleId) {
	this.roleId = roleId;
    }

    public Long getPrivilegeId() {
	return this.privilegeId;
    }
    public void setPrivilegeId(Long privilegeId) {
	this.privilegeId = privilegeId;
    }
}
