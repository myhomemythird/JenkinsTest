package org.richardliao.mybatis.mapper;

import java.util.List;

import org.richardliao.mybatis.model.SysUser;

public interface UserMapper {
    SysUser selectById(Long id);

    List<SysUser> selectAll();
}
