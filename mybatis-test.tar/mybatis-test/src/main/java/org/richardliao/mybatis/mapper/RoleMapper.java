package org.richardliao.mybatis.mapper;

public interface RoleMapper {
    
}
