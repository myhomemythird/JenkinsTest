package org.richardliao.mybatis.model;

public class SysUserRole {
    private Long userId;

    private Long roleId;

    public Long getUserId() {
	return this.userId;
    }
    public void setUserId(Long userId) {
	this.userId = userId;
    }

    public Long getRoleId() {
	return this.roleId;
    }
    public void setRoleId(Long roleId) {
	this.roleId = roleId;
    }
}
