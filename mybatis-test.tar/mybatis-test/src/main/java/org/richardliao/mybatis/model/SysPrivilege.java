package org.richardliao.mybatis.model;

public class SysPrivilege {
    private Long id;

    private String privilegeName;

    private String privilegeUrl;

    public Long getId() {
	return this.id;
    }
    public void setId(Long id) {
	this.id = id;
    }

    public String getPrivilegeName() {
	return this.privilegeName;
    }
    public void setPrivilegeName(String privilegeName) {
	this.privilegeName = privilegeName;
    }

    public String getPrivilegeUrl() {
	return this.privilegeUrl;
    }
    public void setPrivilegeUrl(String privilegeUrl) {
	this.privilegeUrl = privilegeUrl;
    }
}
