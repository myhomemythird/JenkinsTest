package org.richardliao.mybatis.mapper;

import java.util.List;

import org.richardliao.mybatis.model.Country;

public interface CountryMapper {
    List<Country> selectAll();
}
