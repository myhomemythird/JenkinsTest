package org.richardliao.mybatis.model;

import java.util.Date;

public class SysRole {
    private Long id;

    private String roleName;

    private Long enabled;

    private Long createBy;

    private Date createTime;

    public Long getId() {
	return this.id;
    }
    public void setId(Long id) {
	this.id = id;
    }

    public String getRoleName() {
	return this.roleName;
    }
    public void setRoleName(String roleName) {
	this.roleName = roleName;
    }

    public Long getEnabled() {
	return this.enabled;
    }
    public void setEnable(Long enabled) {
	this.enabled = enabled;
    }

    public Long getCreateBy() {
	return this.createBy;
    }
    public void setCreateBy(Long createBy) {
	this.createBy = createBy;
    }

    public Date getCreateTime() {
	return this.createTime;
    }
    public void setCreateTime(Date createTime) {
	this.createTime = createTime;
    }
}
