package org.richardliao.mybatis.model;

public class Country {
    private Long id;
    private String countryname;
    private String countrycode;

    public Long getId(){
	return this.id;
    }
    public void setId(Long id) {
	this.id = id;
    }
    public String getCountryname() {
	return this.countryname;
    }
    public void setCountryname(String countryname) {
	this.countryname = countryname;
    }
    public String getCountrycode() {
	return this.countrycode;
    }
    public void setCountrycode(String countrycode) {
	this.countrycode = countrycode;
    }
}
