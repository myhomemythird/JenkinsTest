package org.richardliao.mybatis.mapper;

public interface UserRoleMapper {
    
}
