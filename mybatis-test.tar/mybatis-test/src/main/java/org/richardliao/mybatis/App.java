package org.richardliao.mybatis;

import org.richardliao.mybatis.mapper.CountryMapperTest;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        CountryMapperTest.init();
	CountryMapperTest cmt = new CountryMapperTest();
	cmt.testSelectAll();
    }
}
